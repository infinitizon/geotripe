# angular-vertical-menu

Check it out [**demo**](http://gnavarro77.github.io/angular-vertical-menu/)
